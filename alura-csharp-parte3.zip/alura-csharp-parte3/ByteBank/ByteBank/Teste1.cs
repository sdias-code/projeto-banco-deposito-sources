﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ByteBank
{
    public class Maior
    {
        public double MaiorNumero(double a, double b)
        {
            if (a > b)
            {
                return a;
            }
            return b;
        }
    }
}
