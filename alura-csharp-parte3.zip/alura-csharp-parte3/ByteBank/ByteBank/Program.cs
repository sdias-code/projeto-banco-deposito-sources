﻿using ByteBank.Funcionarios;
using System;
namespace ByteBank
{
    class Program
    {
        static void Main(string[] args)
        {

            Funcionario carlos = new Funcionario();
            carlos.Nome = "Carlos";
            carlos.CPF = "078.995.654-87";
            carlos.Salario = 2000;

            Maior num = new Maior();
            double resultado = num.MaiorNumero(num.MaiorNumero(5.0, 7.0), 9.0);

            Console.WriteLine("Resultado: " + resultado);
            Console.ReadLine();
        }
    }
}
