﻿namespace ContaCorrente.Domain.ContasCorrentes
{
    public enum TipoTransacao
    {
        Deposito,
        Retirada,
        Pagamento
    }
}
