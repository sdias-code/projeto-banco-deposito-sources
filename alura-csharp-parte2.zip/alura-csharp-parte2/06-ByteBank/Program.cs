﻿using System;

namespace _06_ByteBank
{
    class Program
    {
        static void Main(string[] args)
        {

            ContaCorrente conta = new ContaCorrente();
            conta.SetSaldo(-10);

            Console.WriteLine(conta.GetSaldo());

            Console.WriteLine("Pressione Enter para sair!");
            Console.ReadLine();
        }
    }
}
