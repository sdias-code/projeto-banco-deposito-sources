﻿using System;

namespace ConsoleAppContaFinal
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Antes - Total de contas criadas: " + ContaCorrente.TotalContasCriadas);
            ContaCorrente conta = new ContaCorrente(455, 45578961);

            Console.WriteLine("Depois - Total de contas criadas: " + ContaCorrente.TotalContasCriadas);

            Console.WriteLine("Pressione Enter para Sair!");
            Console.ReadLine();
        }
    }
}
